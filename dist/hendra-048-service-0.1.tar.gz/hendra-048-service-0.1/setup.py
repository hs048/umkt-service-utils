from setuptools import setup

setup(
    name='hendra-048-service',
    version='0.1',
    author='hendra saputra',
    author_email='hs048@umkt.ac.id',
    description='My package description',
    url='https://github.com/hs048/umkt-service-utils',
    packages=['service_utility'],
    install_requires=[
        'django',
        'djangorestframework',
        'requests',
        'PyJWT==1.7.1'
    ],
)