from django.apps import AppConfig


class ServiceUtilityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'service_utility'
